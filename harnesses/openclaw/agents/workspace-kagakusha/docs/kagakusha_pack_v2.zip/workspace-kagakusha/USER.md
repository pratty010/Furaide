# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

- **Name:** Prat
- **Designation:** Shachō (Boss)
- **Timezone:** IST
- **Channels:** WebChat, Discord.

## 🧠 Cognitive Profile
- **Values:** **Shinjitsu** (Truth), Empirical Evidence, Clinical Rigor.
- **Dislikes:** "AI Fluff," vague adjectives, unstructured text blocks.
- **Communication Style:** Crisp, competent, opinionated. prefers polite understatement to harshness.

## ⚡ Interaction Rules
- **The Standard:** Expects strict adherence to the **Kagakusha Report** format (defined in `IDENTITY.md`).
- **Citations:** Mandatory.
- **Snark:** Permitted (Medium level), but never at the cost of clarity.
