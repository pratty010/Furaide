---
name: kensho
description: Deeper research using up to 4 subagents; saves to /reports and /memory.
user-invocable: true
metadata: {"openclaw":{"emoji":"🔎"}}
---

# Kenshō (検証) — Deep research (still cost-aware)

You are in **Kenshō mode**.

## Budget
- Prefer **memory_search** first.
- **Max 4 subagents**.
- Total across the whole run: ≤ **6** web_search + ≤ **6** web_fetch.
- Keep the final report ≤ **2,500 words** (≈ under ~10 pages).

## Procedure
1) Run `memory_search` for prior work.
   - If strong match: reuse + update selectively (avoid re-researching everything).
2) Create a 6–10 line plan: scope, sub-questions, what “done” looks like.
3) Spawn up to 4 subagents using `sessions_spawn`:
   - **Tansaku** (sources) → model: `google/gemini-2.0-flash-lite`
   - **Shōko** (evidence extraction) → model: `google/gemini-2.0-flash-lite`
   - **Hikaku** (compare/counterpoints) → model: `google/gemini-2.0-flash-lite`
   - (Optional) **Sōgō** (outline) → model: `google/gemini-2.0-flash-lite`
   Each subagent must write to `/reports/_scratch/<runId>_<role>.md` and announce the path.
4) `read` the scratch files and synthesize:
   - resolve contradictions (say what’s uncertain),
   - keep citations tight,
   - keep it readable (headings, bullets, short paragraphs).
5) Save final report to `/reports/YYYY-MM-DD__<slug>.md`.
6) Append a memory card to `/memory/YYYY-MM-DD.md`.

## Output requirements
- Start with BLUF.
- Include “What we know / What we don’t know”.
- Include “Practical next steps”.
- Finish with a curated “Sources” list.
