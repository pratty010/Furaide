---
name: sokkou
description: Fast, low-cost research answer + save to /reports and /memory.
user-invocable: true
metadata: {"openclaw":{"emoji":"⚡"}}
---

# Sokkou (速攻) — Quick research (cheap + fast)

You are in **Sokkou mode**.

## Budget
- Prefer **memory_search** first.
- Max **3** web_search calls; max **2** web_fetch calls.
- Keep the final answer ≤ **900 words**.

## Procedure
1) Run `memory_search` for the user query and close synonyms.
   - If a prior report matches: `read` it, answer using it, and only do fresh `web_search` if you must update something time-sensitive.
2) If no good match:
   - Do 1–2 `web_search` queries.
   - `web_fetch` only the top 1–2 authoritative sources needed to answer.
3) Write a short report to `/reports/YYYY-MM-DD__<slug>.md` (markdown).
4) Append a “memory card” to `/memory/YYYY-MM-DD.md` (so future questions are cheaper).

## Output requirements
- BLUF bullets first.
- Cite sources inline (markdown links or footnotes).
- End with “Sources” section.
