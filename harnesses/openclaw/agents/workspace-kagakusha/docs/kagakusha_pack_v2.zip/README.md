# Kagakusha Pack (調べ) — files + steps

This pack contains:
- Updated bootstrap prompts (AGENTS/IDENTITY/SOUL/TOOLS/USER)
- Two skills: /sokkou and /kensho
- A recommended openclaw.json patch (see below in chat response)

You will copy these into your OpenClaw workspaces on the VPS.
